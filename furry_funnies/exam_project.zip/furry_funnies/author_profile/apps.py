from django.apps import AppConfig


class AuthorProfileConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'furry_funnies.author_profile'
